# A Kernel Seedling
TODO: intro
This kernel model demonstrates how to interact with Linux kernel's '/proc' filesystem to report
the current number of running processes

## Building
```shell
TODO: cmd for build -> 'make'
```
To compile the kernel module, run 'make' to produce 'proc_count.ko'

## Running
```shell
TODO: cmd for running binary -> 'sudo insmod proc_count.ko' & 'cat /proc/count' 
```
To run the kernel, 'sudo insmod proc_count.ko' is used and to view the output, use 'cat /proc/count'

TODO: results?
The total number of processes running when I ran the kernel was 174.

## Cleaning Up
```shell
TODO: cmd for cleaning the built binary -> 'sudo rmmod proc_count.ko' & 'make clean' 
```
'make clean' is used to remove all generated files during the build process

## Testing
```python
python -m unittest
```
TODO: results?
"Ran 3 tests in 2.925s

OK"

Report which kernel release version you tested your module on
(hint: use `uname`, check for options with `man uname`).
It should match release numbers as seen on https://www.kernel.org/.

```shell
uname -r -s -v
```
TODO: kernel ver?
Linux 5.14.8-arch1-1